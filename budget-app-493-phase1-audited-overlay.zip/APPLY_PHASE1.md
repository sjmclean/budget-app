# Phase 1 sync-safety overlay for budget-app(493)

This patch was produced from an audit of `budget-app(493).zip`.

## Scope

- Keep selected-budget and budget-open activity device-local.
- Exclude selected-budget state from canonical snapshots/checkpoints.
- Do not journal new device-local writes.
- Skip previously journalled device-local writes during upload while still advancing the local push cursor.
- Ignore old remote device-local operations while still allowing the remote cursor to advance.
- Stop read-only budget-month loading from persisting starter or generated rollover months.
- Remove the unsafe **Keep mine** action and reject programmatic attempts to reapply a complete legacy document.
- Add `test:v493:phase1-sync-safety`.

## 1. Create the rollback point before applying

Run from the repository root:

```bash
git status --short
```

If the output shows intended uncommitted work, save it in the restore point:

```bash
git add -A
git commit -m "Restore point before Phase 1 sync safety"
```

If the working tree is already clean, use the current commit.

Create both a tag and a backup branch:

```bash
git tag -a pre-phase1-sync-safety -m "Before Phase 1 sync safety"
git branch backup/pre-phase1-sync-safety
git rev-parse --short HEAD
git show --no-patch --decorate pre-phase1-sync-safety
```

Optional remote backup:

```bash
git push origin backup/pre-phase1-sync-safety
git push origin pre-phase1-sync-safety
```

## 2. Apply the overlay

```bash
git apply --check /path/to/phase1-sync-safety.patch
git apply /path/to/phase1-sync-safety.patch
git status --short
git diff --check
```

## 3. Use a compatible Node/pnpm combination

The repository does not pin a package manager. On Node 20, use pnpm 10 rather than pnpm 11:

```bash
corepack prepare pnpm@10.28.2 --activate
node -v
pnpm -v
```

Expected: Node 20.x and pnpm 10.x, or Node 22.13+ with pnpm 11.

## 4. Install and validate

Run one command at a time:

```bash
pnpm install --frozen-lockfile
pnpm test:v493:phase1-sync-safety
pnpm test:v492:replication-byte-aware-push
pnpm --filter @budget-app/web build
pnpm test:budget
pnpm audit:persistence:check
```

Inspect the change:

```bash
git diff --stat pre-phase1-sync-safety
git diff pre-phase1-sync-safety -- apps/web/src/features/persistence
```

## 5. Commit the applied phase

```bash
git add -A
git commit -m "Phase 1: isolate device-local state and make budget reads non-persistent"
git tag -a phase1-sync-safety -m "Phase 1 sync safety applied"
```

## Rollback

### Before committing the overlay

```bash
git reset --hard pre-phase1-sync-safety
git clean -fd
```

### After committing the overlay, while preserving later history

```bash
git revert --no-edit phase1-sync-safety^..phase1-sync-safety
```

### Return to the backup branch

```bash
git switch backup/pre-phase1-sync-safety
```

Do not use `git clean -fd` if you have untracked files you still need.

## Validation note

The patch passed `git diff --check` and `git apply --check` against the supplied `budget-app(493).zip`. Package installation and the pnpm test/build commands could not be run in the audit environment because external npm package downloads were unavailable.
