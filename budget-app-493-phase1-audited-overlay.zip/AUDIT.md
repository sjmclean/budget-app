# Audited findings

## Confirmed causes addressed

1. `budget-app.selected-budget-id.v1` was classified as canonical state and therefore included in snapshots/checkpoints.
2. Every IndexedDB `setItem` and `removeItem` created a replication journal entry, including launcher/device state.
3. `markBudgetOpened()` rewrote the entire replicated budget registry solely to update `lastOpenedLabel`.
4. `loadBudgetView()` persisted both missing starter months and generated rollover months during reads.
5. Remote operations were applied without checking whether the key was device-local.
6. The conflict UI allowed `keep-local`, which republished the losing complete JSON document and could overwrite unrelated changes.

## Overlay design

The overlay introduces an explicit replication classification boundary. It keeps the current whole-document protocol for legacy domain records, but prevents known device-local state from participating in that protocol. This is a containment phase, not the final CRDT implementation.

## Deliberately not changed

- The budget registry is still a whole replicated JSON document.
- Accounts, transactions, categories and assignments are still whole-document records.
- Server arrival order remains the deterministic winner for legacy conflicts.
- No entity-field CRDT, logical clock, tombstone or Merkle convergence implementation is included yet.
