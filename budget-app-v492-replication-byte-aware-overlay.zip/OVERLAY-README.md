# v492 replication byte-aware push overlay

This overlay is built specifically against `budget-app(492).zip`.

## Files changed

- `apps/web/src/features/persistence/replicationEngine.ts`
- `apps/web/src/features/persistence/replicationTransport.ts`
- `apps/web/src/features/persistence/replication.ts`
- `apps/server/src/replicationStore.mjs`
- `package.json`

## Files added

- `apps/web/src/features/persistence/replicationPushBatch.ts`
- `tests/v492-replication-byte-aware-push.ts`
- `docs/replication-v492-audit-and-remediation.md`

## Validation command

```bash
pnpm test:v490:replication-trace
pnpm test:v492:replication-byte-aware-push
pnpm --filter @budget-app/web build
```

Do not re-import the YNAB4 budget. Restart `pnpm dev`, leave the importing browser open, and allow the existing journal to resume from its persisted pushed sequence.
